//Bibliotecas
#include <iostream>
using std::cout;
using std::cin;
using std::cerr;
using std::endl;
using std::fixed;
using std::left;
using std::right;
using std::ios;
using std::showpoint;

#include <fstream>
using std::fstream;
using std::ofstream;
using std::ostream;
using std::ifstream;

#include <cstdlib>
using std::exit;

#include <iomanip>
using std::setprecision;
using std::setw;

#include <cstdlib>
using std::exit;

#include <string>
using std::string;

#include <unordered_map>
#include <vector>
#include <iomanip>